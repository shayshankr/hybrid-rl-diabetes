# Results

**Setup.** We evaluate two controllers in a one-day (72-step) diabetes simulator with the following parameters:
`max_steps=72`, `max_units=10.0`, `extra_alpha=-30.0`, `insulin_penalty_coef=0.0`.
The RL policy is PPO trained on the simulator; the rule policy is a proportional controller (KP tuned on validation).

**Validation (n=30 episodes).**  
- **Rule:** TIR=0.000% · Hypo=1.0 · Hyper=71.0 · U/step=9.815  
- **PPO:** TIR=0.000% · Hypo=0.0 · Hyper=72.0 · U/step=1.200  
- **Interpretation:** PPO doses far less insulin than Rule (**87.8% reduction**), but both policies show low TIR on this configuration.

**Test (n=30 episodes).**  
- **Rule:** TIR=1.389% · Hypo=1.0 · Hyper=70.0 · U/step=9.722  
- **PPO:** TIR=1.389% · Hypo=0.0 · Hyper=71.0 · U/step=1.343  
- **Interpretation:** PPO again achieves a drastic **86.2% reduction** in average dosing versus Rule while matching TIR and eliminating hypoglycemia in this test split.

**Action profiles.** Figure 2 shows that the Rule controller saturates near the action limit (∼9.722 U/step average on TEST), whereas PPO actions are concentrated near zero (∼1.343 U/step average), consistent with a conservative dosing policy.

**Takeaway.** In this simulator setting, the hybrid framework yields a safe-leaning PPO policy that substantially lowers insulin exposure without meaningful TIR gains yet. This supports the transparency/controllability goal (clear dosing patterns), while highlighting the need for better dynamics or reward shaping to translate conservatism into improved glycemia.
