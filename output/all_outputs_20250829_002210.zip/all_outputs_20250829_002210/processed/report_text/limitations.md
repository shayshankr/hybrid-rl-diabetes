# Limitations and Future Work

- **Simulator correction.** We enforced a stabilizing prior by setting `extra_alpha=-30.0` to ensure insulin monotonically reduces glucose in the learned dynamics. This hard-coded correction is pragmatic for this academic prototype and should be replaced by stronger data-driven constraints or clinical priors in future work.
- **Low TIR despite conservative dosing.** The PPO policy learns to avoid hypoglycemia by reducing dosing, but TIR remains low. Future directions: (i) multi-objective reward with explicit TIR terms, (ii) model-based planning over the learned dynamics with safety filters, and (iii) richer state (meals, basal rates) to reduce partial observability.
- **Single-patient/day horizon.** Results reflect a 24-hour horizon and simplified physiology; scaling to multi-day horizons and inter-patient variability is a next step.
