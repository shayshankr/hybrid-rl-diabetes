# Figure Captions

**Figure 1. Head-to-head summary (VAL/TEST).** Tabular comparison of Rule vs PPO across TIR, hypo/hyper steps, and average insulin per step (see `summary_table.png`). PPO achieves ~86.2% lower dosing than Rule on TEST with comparable TIR.

**Figure 2. Action distributions (TEST).** Histogram and bar plots of actions (`action_hist_test.png`, `action_bar_test.png`). Rule doses cluster near the maximum, while PPO is concentrated near zero, indicating a conservative strategy.

**Figure 3. Trajectories — Validation, Episode 1.** Glucose and insulin trajectories (`traj_compare_val_ep1_glucose.png`, `traj_compare_val_ep1_insulin.png`). PPO uses much smaller boluses than Rule; both remain largely hyperglycemic in this setting.

**Figure 4. Trajectories — Test, Episode 1.** Glucose and insulin trajectories (`traj_compare_test_ep1_glucose.png`, `traj_compare_test_ep1_insulin.png`). Similar pattern: large Rule doses vs small PPO doses, with comparable TIR outcomes.
